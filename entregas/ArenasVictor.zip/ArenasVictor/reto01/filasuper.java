package reto1;

public class filasuper {

    static int tiempo_reto_base = 240;
    static int tiempo_reto_extendido = 120;
    static int minuto_reglas_nuevas = 20;
    static int capacidad_maxima_fila = 30;
    static int auxiliar_maximo = 500;

    static class Cliente {

        static int contador = 1;
        int id;
        int minutoLlegada;
        boolean esPreferente;

        public Cliente(int minutoLlegada, boolean esPreferente) {
            this.id = contador++;
            this.minutoLlegada = minutoLlegada;
            this.esPreferente = esPreferente;
        }
    }

    public static void main(String[] args) {
        System.out.println("Reto Base:");
        retoBase();
        System.out.println("\nReto Extendido:");
        retoExtendido();
    }

    private static void retoBase() {
        Cliente[] fila = new Cliente[tiempo_reto_base];
        int tamañoFila = 0;
        int clientesAtendidos = 0;

        for (int minuto = 1; minuto <= tiempo_reto_base; minuto++) {

            if (hayEvento(0.60)) {
                fila[tamañoFila] = new Cliente(minuto, false);
                tamañoFila++;
            }

            if (hayEvento(0.40) && tamañoFila > 0) {
                tamañoFila = eliminarClientePosicion(fila, tamañoFila, 0);
                clientesAtendidos++;
            }
        }

        System.out.println("Clientes atendidos: " + clientesAtendidos);
        System.out.println("Clientes en fila al cerrar: " + tamañoFila);
    }

    private static void retoExtendido() {
        Cliente[] fila = new Cliente[auxiliar_maximo];
        int tamañoFila = 0;
        int clientesAtendidos = 0;
        int desisten = 0;
        int aburridos = 0;
        int fusiones = 0;

        for (int minuto = 1; minuto <= tiempo_reto_extendido; minuto++) {

            boolean reglasActivas = minuto >= minuto_reglas_nuevas ? true : false;

            if (reglasActivas && minuto % 15 == 0 && tamañoFila > 25) {
                System.out.println("Pasen por esta caja en orden de fila");
                int personasAtender = Math.min(3, tamañoFila);
                for (int i = 0; i < personasAtender; i++) {
                    tamañoFila = eliminarClientePosicion(fila, tamañoFila, 0);
                    clientesAtendidos++;
                }
            }

            if (reglasActivas && minuto % 5 == 0) {
                for (int i = tamañoFila - 1; i >= 0; i--) {
                    int tiempoEspera = minuto - fila[i].minutoLlegada;
                    if (tiempoEspera > 8 && hayEvento(0.30)) {
                        tamañoFila = eliminarClientePosicion(fila, tamañoFila, i);
                        aburridos++;
                    }
                }
            }
            if (reglasActivas && hayEvento(0.05) && tamañoFila > 1){
                int posPersonaSeVa = (int) (Math.random() * tamañoFila);
                tamañoFila = eliminarClientePosicion(fila, tamañoFila, posPersonaSeVa);
                fusiones++;
            }
            if (hayEvento(0.60)) {
                if (tamañoFila > capacidad_maxima_fila && hayEvento(0.50)) {
                    desisten++;
                } else {
                    boolean esPreferente = (reglasActivas && hayEvento(0.20)) ? true : false;

                    if (esPreferente) {
                        tamañoFila = insertarClientePreferente(fila, tamañoFila, new Cliente(minuto, true));
                    } else {
                        fila[tamañoFila] = new Cliente(minuto, false);
                        tamañoFila++;
                    }
                }
            } else if (reglasActivas && hayEvento(0.10) && tamañoFila > 0) {
                if (tamañoFila > capacidad_maxima_fila && hayEvento(0.50)) {
                    desisten++;
                } else {
                    int posConocido = (int) (Math.random() * tamañoFila);
                    tamañoFila = insertarClienteEnPosicion(fila, tamañoFila, posConocido + 1, new Cliente(minuto, false));                }
            }

            if (hayEvento(0.40) && tamañoFila > 0) {
                tamañoFila = eliminarClientePosicion(fila, tamañoFila, 0);
                clientesAtendidos++;            
            }
            System.out.println("Minuto: " + minuto + ", Tamaño de la fila: " + tamañoFila);
        }
        mostrarResultadosExt(clientesAtendidos, tamañoFila, aburridos, desisten, fusiones);
    }

    private static boolean hayEvento(double probabilidad) {
        return Math.random() < probabilidad;
    }

    private static int eliminarClientePosicion(Cliente[] fila, int tamañoActual, int indice) {
        for (int i = indice; i < tamañoActual - 1; i++) {
            fila[i] = fila[i + 1];
        }
        fila[tamañoActual - 1] = null;
        return tamañoActual - 1;
    }

    private static int insertarClienteEnPosicion(Cliente[] fila, int tamañoActual, int indice, Cliente nuevo) {
        for (int i = tamañoActual; i > indice; i--) {
            fila[i] = fila[i - 1];
        }
        fila[indice] = nuevo;
        return tamañoActual + 1;
    }

    private static int insertarClientePreferente(Cliente[] fila, int tamañoActual, Cliente nuevo) {
        int posicionInsertar = 0;
        for (int i = 0; i < tamañoActual; i++) {
            if (fila[i].esPreferente) {
                posicionInsertar = i + 1;
            }
        }
        return insertarClienteEnPosicion(fila, tamañoActual, posicionInsertar, nuevo);
    }

    private static void mostrarResultadosExt(int atendidos, int enFila, int aburridos, int desisten, int fusiones) {
        System.out.println("Clientes atendidos: " + atendidos);
        System.out.println("Clientes en fila al cerrar: " + enFila);
        System.out.println("Clientes que se aburrieron y se fueron: " + aburridos);
        System.out.println("Clientes que desistieron de entrar: " + desisten);
        System.out.println("Clientes que se fusionaron: " + fusiones);
    }
}
